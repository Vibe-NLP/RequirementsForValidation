LICENSING
=========

  Copyright (c) 1998 Nalante, Inc.

  A royalty-free license is granted for the use of this software for
  NON_COMMERCIAL PURPOSES ONLY. 

  The program is provided "as is" without warranty of any kind, either
  expressed or implied, including, but not limited to, the implied
  warranties of merchantability and fitness for a particular purpose.
  The entire risk as to the quality and performance of the program is
  with you.  Should the program prove defective, you assume the cost of
  all necessary servicing, repair or correction.

Contact
=======

  Dekang Lin
  Nalante, Inc.
  245 Falconer End
  Edmonton, Alberta, Canada, T6R 2V6
  Email: <lindek@nalante.com>
  Phone: (780) 432 5288
  Fax:   (780) 988 0184

ABOUT MINIPAR
=============

  MINIPAR is a broad-coverage parser for the English language. An
  evaluation with the SUSANNE corpus shows that MINIPAR achieves about
  88% precision and 80% recall with respect to dependency
  relationships. MINIPAR is very efficient, on a Pentium II 300 with
  128MB memory, it parses about 300 words per second.

INSTALLATION
============

  0. Choose an installing directory.
  1. Unzip/Untar the file minipar-VERSION-PLATFORM.{tgz,zip}
  2. Set the environment variable MINIPATH to be .:DIR/data where DIR is
     the directory in which minipar-VERSION-PLATFORM.{tgz,zip} is
     unzip/untar'ed. 
  
  The directory contains several subdirectories:
  lib_win32:      the MINIPAR library for WIN32
  lib_linux:      the MINIPAR library for Linux
  lib_solaris:    the MINIPAR library for Solaris
  data:     lexicon, grammar and other data files.
  include:  include files for MINIPAR API.
  pdemo:    an example use of the MINIPAR API.


APPLICATION PROGRAM INTERFACE
=============================

  The API minipar is defined in include/ptree.h. A parse tree is
  stored in a data structure called ParseTree.
  
  The API include the following functions:
  
    void initialize_minipar(const char* paths);
    void parse(const char* sentence, ParseTree& parse_tree);
    void parse(const char* words[], ParseTree& parse_tree);
    void extract_features(char* features);
  
  The 'initialize_minipar' function initialize the parser. It should be
  called exactly once before the parser is used. The argument 'paths' is
  a sequence of names of directories where the data files are to be
  found. The directory names are deliminated by colon on UNIX machines
  and by semicolon on Windows. 
  
  Example:
  	initialize_minipar(".:../data");
  
  The two 'parse' functions take a sentence and a ParseTree object as
  arguments.  The sentence is stored in a NULL-terminated character
  array or an array of character pointers, each of which points to a
  word.  The resulting parse tree is stored in the ParseTree object
  passed to the function.
  
  Examples:
  	parse("this is a test.", parse_tree);
  
  	char* words[] = {"this", "is", "a", "test", ".", 0};
  	parse(words, parse_tree);
  	
  Each node in the parse tree may contain a set of features. The
  complete set of features are defined in data/gbatt.lsp.  The
  'extract_features' functions tells the parser which features are to be
  included in the parse tree.
  
  Example:
  	extract_features("plu tense");

PDEMO
=====

  A program named pdemo is included in this distribution as
  demonstration program. This program reads each line in the the
  standard input as a sentence and prints out the parse tree of the
  sentence. The program is evoked with
  
  pdemo [-c] [-r] [-l] [-p MINIPATH] [-f "feature feature ..."] 
  
  -c 
      Return the constituency tree instead of the dependency tree.
  
  -f "feature feature ..."
      Print the features listed after -f.

  -i
      Do not print the prompt "> ".
  
  -l
      Print the name of the grammatical relation between a node and its
      parent.
  
  -p MINIPATH
      If the environment variable MINIPATH is not defined. This option
      will be need to tell the parser where the data files are.
  
  -r
      Print the root forms of words.
  
  -t
      Print the depdenency triples instead of parse trees. Each
      dependency triple consists of a head, a relationship and a
      modifier, separated by a tab. The -t option implies -d.

  Example:
	pdemo -p ../data <A01
  

GRAMMATICAL CATEGORIES

The meanings of grammatical categories are explained as follows: 

  Det: Determiners
  PreDet: Pre-determiners (search for PreDet in data/wndict.lsp for instances)
  PostDet: Post-determiners (search for PostDet in data/wndict.lsp for instances)
  NUM: numbers
  C: Clauses
  I: Inflectional Phrases
  V: Verb and Verb Phrases
  N: Noun and Noun Phrases
  NN: noun-noun modifiers
  P: Preposition and Preposition Phrases
  PpSpec: Specifiers of Preposition Phrases (search for PpSpec 
          in data/wndict.lsp for instances)
  A: Adjective/Adverbs
  Have: have
  Aux:  Auxilary verbs, e.g. should, will, does, ...
  Be:   Different forms of be: is, am, were, be, ... 
  COMP:  Complementizer
  VBE: be used as a linking verb. E.g., I am hungry
  V_N	verbs with one argument (the subject), i.e., intransitive verbs
  V_N_N verbs with two arguments, i.e., transitive verbs
  V_N_I verbs taking small clause as complement

GRAMMATICAL RELATIONSHIPS

The following is a list of all the grammatical relationships in
Minipar. Search for (dep-type relation) in data/minipar.lsp for the
meaning of relation.

appo	"ACME president, --appo-> P.W. Buckman"
aux     "should <-aux-- resign"
be      "is <-be-- sleeping"
c       "that <-c-- John loves Mary"
comp1	first complement
det	"the <-det `-- hat"
gen	"Jane's <-gen-- uncle"
have	"have <-have-- disappeared"
i	the relationship between a C clause and its I clause
inv-aux inverted auxiliary: "Will <-inv-aux-- you stop it?
inv-be  inverted be: "Is <-inv-be-- she sleeping"
inv-have inverted have: "Have <-inv-have-- you slept"
mod	the relationship between a word and its adjunct modifier
pnmod   post nominal modifier
p-spec  specifier of prepositional phrases
pcomp-c clausal complement of prepositions
pcomp-n nominal complement of prepositions
post    post determiner
pre     pre determiner
pred    predicate of a clause
rel     relative clause
vrel    passive verb modifier of nouns
wha, whn, whp: wh-elements at C-spec positions
obj     object of verbs
obj2	second object of ditransitive verbs
subj	subject of verbs
s	surface subject

